#!/bin/bash

ROOT_DIR="/home/rajtendulkar/eclipse-workspace/Java-WorkSpace/spdf_with_Z3_integrated"
for i in {1..10}
do
	mv ${ROOT_DIR}/outputFiles/Dct$i/ ${ROOT_DIR}/outputFiles/Dct/
	./mainTestScript.sh
	mv ${ROOT_DIR}/outputFiles/Dct/ ${ROOT_DIR}/outputFiles/Dct$i/
done
