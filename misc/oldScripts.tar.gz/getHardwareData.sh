#!/bin/bash

INPUT_DIR="outputFiles/mergeSort/scheduling"
OUTPUT_DIR="outputFiles/mergeSort/hardware_output"


MACHINE="kalray2-eth0"
REMOTE_PATH="/home/rajtendulkar/workspace/framework_cpp/"
APPLICATION="MergeSort"

ROOT_DIR="/mnt/extra/eclipse-workspace/Java-WorkSpace/spdf_with_Z3_integrated"
JAR_DIR="$ROOT_DIR/dep/Z3Lib"
BIN_DIR="$ROOT_DIR/bin"

#javac -sourcepath src/ -classpath ./dep/Z3Lib/com.microsoft.z3.jar -d bin/ src/*.java 
#rm -rf $OUTPUT_DIR
mkdir -p $OUTPUT_DIR 
SCHEDULES=`ls $INPUT_DIR/`

for sched in $SCHEDULES
do
	SOLUTIONS=`ls -d $INPUT_DIR/$sched/solution* | cut -f5 -d "/"`
	for sol in $SOLUTIONS
	do
		echo $sched : $sol
		mkdir -p $OUTPUT_DIR/$sched/$sol
		echo $INPUT_DIR/$sched/$sol/solution.xml
		scp $INPUT_DIR/$sched/$sol/solution.xml $MACHINE:${REMOTE_PATH}/solution.xml
		ssh $MACHINE "cd $REMOTE_PATH ; make all run-hw APPLICATION=$APPLICATION APPLICATION_ARGS="solution.xml" ; rm -f solution.xml ; exit"
		scp $MACHINE:${REMOTE_PATH}/defaultProfile.xml $OUTPUT_DIR/$sched/$sol/profile.xml
		scp $MACHINE:${REMOTE_PATH}/rawData.txt $OUTPUT_DIR/$sched/$sol/rawData.txt
		java -classpath $BIN_DIR:$JAR_DIR/com.microsoft.z3.jar:$JAR_DIR TryParseLogKalray -lg $OUTPUT_DIR/$sched/$sol/rawData.txt -gc $OUTPUT_DIR/$sched/$sol/hardware.pdf
		cp $INPUT_DIR/$sched/$sol/solution.pdf $OUTPUT_DIR/$sched/$sol/solver.pdf
	done
done
