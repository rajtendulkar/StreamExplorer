#!/bin/bash

PLATFORM_XML="inputFiles/hardware_platform/kalray_mesh.xml"

REMOTE_MACHINE="kalray-eth0"
REMOTE_WORKING_DIR="/home/rajtendulkar/workspace/framework_peek"

PER_QUERY_TIMEOUT_IN_SECONDS=180
#TIMEOUT_IN_SECONDS=600
TIMEOUT_IN_SECONDS=1800

HOME_DIR="/home/rajtendulkar/eclipse-workspace/Java-WorkSpace/spdf_with_Z3_integrated"
BIN_DIR="$HOME_DIR/bin"
TOP_OUTPUT_DIR="outputFiles"
ARCH=""

# "YES" or "NO"
GENERATE_CSV="YES"


# Application-Name      Enable/Disable      Run-Profile     Run Design Flow     Execute App on Hardware  Profile XML file							local outputDir
tests=( 
"JpegDecoder"            "1"                "0"                 "0"                     "0"				"inputFiles/JpegDecoder/profile.xml"			"JpegDecoder"
"InsertionSort"          "1"                "0"                 "0"                     "0"				"inputFiles/InsertionSort/profile.xml"			"InsertionSort"
"MergeSort"              "1"                "0"                 "0"                     "0"				"inputFiles/MergeSort/profile.xml"				"MergeSort"
"RadixSort"              "1"                "0"                 "0"                     "0"				"inputFiles/RadixSort/profile.xml"				"RadixSort"
"Fft"                    "1"                "0"                 "1"                     "0"				"inputFiles/Fft/profile.xml"					"Fft"
"MatrixMult"             "1"                "0"                 "0"                     "0"				"inputFiles/MatrixMult/profile.xml"				"MatrixMult"
"ComparisonCounting"     "1"                "0"                 "0"                     "0"				"inputFiles/ComparisonCounting/profile.xml"		"ComparisonCounting"
"BeamFormer"             "1"                "0"                 "0"                     "0"				"inputFiles/BeamFormer/profile.xml"				"BeamFormer"
"Dct"                    "1"                "0"                 "0"                     "0"				"inputFiles/Dct/profile/complete1.xml"			"Dct1"
"Dct"                    "1"                "0"                 "0"                     "0"				"inputFiles/Dct/profile/complete2.xml"			"Dct2"
"Dct"                    "1"                "0"                 "0"                     "0"				"inputFiles/Dct/profile/complete3.xml"			"Dct3"
"Dct"                    "1"                "0"                 "0"                     "0"				"inputFiles/Dct/profile/complete4.xml"			"Dct4"
"Dct"                    "1"                "0"                 "0"                     "0"				"inputFiles/Dct/profile/complete5.xml"			"Dct5"
"Dct"                    "1"                "0"                 "0"                     "0"				"inputFiles/Dct/profile/complete6.xml"			"Dct6"
"Dct"                    "1"                "0"                 "0"                     "0"				"inputFiles/Dct/profile/complete7.xml"			"Dct7"
"Dct"                    "1"                "0"                 "0"                     "0"				"inputFiles/Dct/profile/complete8.xml"			"Dct8"
"Dct"                    "1"                "0"                 "0"                     "1"				"inputFiles/Dct/profile/dct2DCoarse.xml"		"Dct9"
"Dct"                    "1"                "0"                 "0"                     "1"				"inputFiles/Dct/profile/dct2DFine.xml"			"Dct10"
)


###########################################################################################################

if [ -z "$ARCH" ] 
then
	MACHINE=`uname -m`
	if [ "$MACHINE" = "i686" ]
	then
		ARCH="32-bit"
	elif [ "$MACHINE" = "x86_64" ]
	then
		ARCH="64-bit"
	else
		echo "Unable to determine if Kernel is 32-bit or 64-bit"
		echo "Set ARCH variable manually in the script (32-bit / 64-bit)"
		exit
	fi
fi

#export LD_LIBRARY_PATH="$HOME_DIR/dep/Z3Lib/$ARCH":$LD_LIBRARY_PATH
LD_LIBRARY_PATH="$HOME_DIR/dep/Z3Lib/$ARCH" 
echo $LD_LIBRARY_PATH
JAR_DIR="$HOME_DIR/dep/Z3Lib/$ARCH"

JAVA_FLAGS="-Djava.library.path=$JAR_DIR -classpath $JAR_DIR/com.microsoft.z3.jar:$BIN_DIR:$JAR_DIR"

# Compile the Java code.
javac -sourcepath src/ -d bin/ src/*.java -classpath $JAR_DIR/com.microsoft.z3.jar


# Function to profile application on the hardware platform.
# Arguments - 
#1 - application name.
#2 - Profile XML file
#3 - output directory name
function profile_application {
	local APPLICATION=$1
	local PROFILE_XML=$2
	local CURRENT_OUTPUT_DIR="$TOP_OUTPUT_DIR/$3/profile"
	ssh $REMOTE_MACHINE "cd $REMOTE_WORKING_DIR ; make all run-hw APPLICATION=$APPLICATION APPLICATION_ARGS="$PROFILE_XML" ; exit"
	mkdir -p "$CURRENT_OUTPUT_DIR"
	scp $REMOTE_MACHINE:${REMOTE_WORKING_DIR}/defaultProfile.xml ${CURRENT_OUTPUT_DIR}/

	# Generate the XML File which we should use for the design flow.
    java $JAVA_FLAGS TryParseProfileInfo -px ${CURRENT_OUTPUT_DIR}/defaultProfile.xml -ox ${CURRENT_OUTPUT_DIR}/${APPLICATION}.xml
}


# Perform Design Space Exploration of the application
# Arguments - 
#1 - application name.
#2 - application output directory name
function periodProcessorExploration {
	local APPLICATION=$1
	local APP_OUTPUT_DIR=$2
	local CURRENT_OUTPUT_DIR="$TOP_OUTPUT_DIR/$APP_OUTPUT_DIR/designFlow"
	mkdir -p $CURRENT_OUTPUT_DIR
	local CONFIG_FLAGS="-localtimeout $PER_QUERY_TIMEOUT_IN_SECONDS -globaltimeout $TIMEOUT_IN_SECONDS -pg ${PLATFORM_XML} -od ${CURRENT_OUTPUT_DIR}/"
	CONFIG_FLAGS="$CONFIG_FLAGS -solver periodLocality -disablePrime True -psym True -gsym True -leftEdge False -proc 16 -ag $TOP_OUTPUT_DIR/$APP_OUTPUT_DIR/profile/$APPLICATION.xml"
	EXEC_COMMAND="java ${JAVA_FLAGS} exploration.query.pareto.PeriodProcExploration ${CONFIG_FLAGS}"
	echo ${EXEC_COMMAND}
	java ${JAVA_FLAGS} exploration.query.pareto.PeriodProcExploration ${CONFIG_FLAGS}
}


# Execute the solution of design space exploration on the hardware
# Arguments - 
#1 - application name.
#2 - application output directory name
function executeSolutionsOnHardware {
	local APPLICATION=$1
	local APP_OUTPUT_DIR=$2
	local SOLUTION_DIR="$TOP_OUTPUT_DIR/$APP_OUTPUT_DIR/designFlow"
	local CURRENT_OUTPUT_DIR="$TOP_OUTPUT_DIR/$APP_OUTPUT_DIR/hardware_output"
	mkdir -p ${CURRENT_OUTPUT_DIR}

	local SOLUTIONS=`ls -d $SOLUTION_DIR/solution* | cut -f4 -d "/" | sort -V`
	for sol in $SOLUTIONS
	do
		echo "Testing $sol on the hardware"
		mkdir -p $CURRENT_OUTPUT_DIR/$sol
		scp $SOLUTION_DIR/$sol/schedule.xml ${REMOTE_MACHINE}:${REMOTE_WORKING_DIR}/schedule.xml
        ssh $REMOTE_MACHINE "cd $REMOTE_WORKING_DIR ; make all run-hw APPLICATION=$APPLICATION APPLICATION_ARGS="schedule.xml" | tee execution.txt ; rm -f schedule.xml ; exit"
        scp $REMOTE_MACHINE:${REMOTE_WORKING_DIR}/rawData.txt $CURRENT_OUTPUT_DIR/$sol/rawData.txt
        scp $REMOTE_MACHINE:${REMOTE_WORKING_DIR}/defaultProfile.xml $CURRENT_OUTPUT_DIR/$sol/profile.xml
        scp $REMOTE_MACHINE:${REMOTE_WORKING_DIR}/execution.txt $CURRENT_OUTPUT_DIR/$sol/execution.txt
        ssh $REMOTE_MACHINE "cd $REMOTE_WORKING_DIR ; rm -f defaultProfile.xml rawData.txt execution.txt ; exit"
        java $JAVA_FLAGS TryParseLogKalray -lg $CURRENT_OUTPUT_DIR/$sol/rawData.txt -gc $CURRENT_OUTPUT_DIR/$sol/hardware.pdf
	done
}

# Execute the solution of design space exploration on the hardware
# Arguments - 
#1 - application name.
#2 - application output directory name
function generateCsv {
	local APPLICATION=$1
	local APP_OUTPUT_DIR=$2
	local solutionCount=0
	
	cat $TOP_OUTPUT_DIR/$APP_OUTPUT_DIR/designFlow/paretoPoints.txt | while read -r line 
	do
		logFile="$TOP_OUTPUT_DIR/$APP_OUTPUT_DIR/hardware_output/solution_$solutionCount/execution.txt"

		period=`echo $line | cut -f 3 -d " "`
		processors=`echo $line | cut -f 6 -d " "`

		periodMin=`cat $logFile | grep "Period  Min :" | cut -f 5 -d " "`
		periodMax=`cat $logFile | grep "Period  Min :" | cut -f 8 -d " "`
		periodAvg=`cat $logFile | grep "Period  Min :" | cut -f 11 -d " "`
		periodDev=`cat $logFile | grep "Period  Min :" | cut -f 14 -d " "`
		
		latencyMin=`cat $logFile | grep "Latency Min :" | cut -f 4 -d " "`
		latencyMax=`cat $logFile | grep "Latency Min :" | cut -f 7 -d " "`
		latencyAvg=`cat $logFile | grep "Latency Min :" | cut -f 10 -d " "`
		latencyDev=`cat $logFile | grep "Latency Min :" | cut -f 13 -d " "`
		
		ThruPutMin=`cat $logFile | grep "ThroughPut Min :" | cut -f 4 -d " "`
		ThruPutMax=`cat $logFile | grep "ThroughPut Min :" | cut -f 7 -d " "`
		ThruPutAvg=`cat $logFile | grep "ThroughPut Min :" | cut -f 10 -d " "`

		echo "$APPLICATION, solution_$solutionCount, $processors, $period, $periodMin, $periodMax, $periodAvg, $periodDev, $latencyMin, $latencyMax, $latencyAvg, $latencyDev, $ThruPutMin, $ThruPutMax, $ThruPutAvg"

		let "solutionCount += 1"
	done
}

if [ ${GENERATE_CSV} == "YES" ] ; then
	echo "Application Name, Solution, Processors, Period, Period, , , , Latency, , , , Throughput, , " > output.csv
	echo ", , , , Min, Max, Avg, Std. Dev., Min, Max, Avg, Std. Dev., Min, Max, Avg" >> output.csv
fi

for (( i = 0; i < ${#tests[*]} ; i+=7 ))
do
    if [ "${tests[$i+1]}" == "1" ]; then

        mkdir -p $TOP_OUTPUT_DIR/${tests[$i+6]}

        # Check if we have to run profiling.
        if [ "${tests[$i+2]}" == "1" ]; then
            profile_application ${tests[$i]} ${tests[$i+5]} ${tests[$i+6]} | tee profile_log.txt
            mv profile_log.txt $TOP_OUTPUT_DIR/${tests[$i+6]}/profile/
        fi

        # Check if we have to run design flow
        if [ "${tests[$i+3]}" == "1" ]; then
 			periodProcessorExploration ${tests[$i]} ${tests[$i+6]} | tee designFlow_log.txt
			mv designFlow_log.txt $TOP_OUTPUT_DIR/${tests[$i+6]}/designFlow/
        fi

        # Check if we have to execute the app on the hardware.
        if [ "${tests[$i+4]}" == "1" ]; then
            executeSolutionsOnHardware ${tests[$i]} ${tests[$i+6]} | tee execution_log.txt
            mv execution_log.txt $TOP_OUTPUT_DIR/${tests[$i+6]}/hardware_output
        fi

		if [ ${GENERATE_CSV} == "YES" ] ; then
			generateCsv ${tests[$i]} ${tests[$i+6]} >> output.csv
			echo ",,,,,,,,," >> output.csv
		fi
    fi
done

