#!/bin/bash

MAIN_OUTPUT_DIR="outputFiles"

PLATFORM_XML="inputFiles/hardware_platform/kalray_mesh.xml"
MACHINE="kalray1-eth0"
REMOTE_PATH="/home/rajtendulkar/workspace/framework_cpp"
PER_QUERY_TIMEOUT_IN_SECONDS=180
TIMEOUT_IN_SECONDS=600

ROOT_DIR="/mnt/extra/eclipse-workspace/Java-WorkSpace/spdf_with_Z3_integrated"
JAR_DIR="$ROOT_DIR/dep/Z3Lib"
BIN_DIR="$ROOT_DIR/bin"

# Compile the Java code.
javac -sourcepath src/ -d bin/ src/*.java -classpath dep/Z3Lib/com.microsoft.z3.jar

# Application-Name      Enable/Disable		Run-Profile 	Run Design Flow 	Execute App on Hardware
tests=( 
"JpegDecoder"          	 "0"				"0"					"1"						"0"
"InsertionSort" 		 "0"        		"0"					"1"						"0" 
"MergeSort"				 "0"				"0"					"1"						"0"
"RadixSort"				 "0"				"0"					"1"						"0"
"Fft"				 	 "0"				"0"					"1"						"0"
"MatrixMult"		 	 "0"				"0"					"1"						"0"
"ComparisonCounting"     "0"				"0"					"1"						"0"
"Dct"				 	 "0"				"0"					"1"						"0"
"BeamFormer"			 "1"				"0"					"1"						"0" 
)

###########################################################################################################

JAVA_FLAGS="-Djava.library.path=$JAR_DIR -classpath $JAR_DIR/com.microsoft.z3.jar:$BIN_DIR:$JAR_DIR"

# Arguments - 
#1 - application name.
function profile_application {
	local APPLICATION=$1
	local CURRENT_OUTPUT_DIR="$MAIN_OUTPUT_DIR/$APPLICATION/profile"
	ssh $MACHINE "cd $REMOTE_PATH ; make all run-hw APPLICATION=$APPLICATION APPLICATION_ARGS="inputFiles/$APPLICATION/profile.xml" ; exit"
	mkdir -p $CURRENT_OUTPUT_DIR
	scp $MACHINE:${REMOTE_PATH}/defaultProfile.xml ${CURRENT_OUTPUT_DIR}/

	# Generate the XML File which we should use for the design flow.
	java $JAVA_FLAGS TryParseProfileInfo -px ${CURRENT_OUTPUT_DIR}/defaultProfile.xml -ox ${CURRENT_OUTPUT_DIR}/${APPLICATION}.xml
}

# Arguments - 
#1 - application name.
function designFlow {
	local APPLICATION=$1
	local CURRENT_OUTPUT_DIR="$MAIN_OUTPUT_DIR/$APPLICATION"
	mkdir -p $CURRENT_OUTPUT_DIR/designFlow/
	local COMMON_FLAGS="-localtimeout $PER_QUERY_TIMEOUT_IN_SECONDS -globaltimeout $TIMEOUT_IN_SECONDS -pg ${PLATFORM_XML} -od ${CURRENT_OUTPUT_DIR}/designFlow/"
	echo "java $JAVA_FLAGS TryDesignFlow -ag ${CURRENT_OUTPUT_DIR}/profile/${APPLICATION}.xml ${COMMON_FLAGS}"
	java $JAVA_FLAGS TryDesignFlow -ag ${CURRENT_OUTPUT_DIR}/profile/${APPLICATION}.xml ${COMMON_FLAGS}
}

# Arguments - 
#1 - application name.
function executeOnHardware {
	local APPLICATION=$1
	local SCHED_DIR="$MAIN_OUTPUT_DIR/$APPLICATION/designFlow/scheduling"
	local CURRENT_OUTPUT_DIR="$MAIN_OUTPUT_DIR/$APPLICATION/hardware_output"
	mkdir -p ${CURRENT_OUTPUT_DIR}
	local SCHEDULES=`ls $SCHED_DIR/ | sort -V`

	for sched in $SCHEDULES
	do
		 local SOLUTIONS=`ls -d $SCHED_DIR/$sched/solution* | cut -f6 -d "/" | sort -V`
		 for sol in $SOLUTIONS
		 do 
			 echo $sched : $sol
			 mkdir -p $CURRENT_OUTPUT_DIR/$sched/$sol
			 echo $SCHED_DIR/$sched/$sol/solution.xml
			 scp $SCHED_DIR/$sched/$sol/solution.xml $MACHINE:${REMOTE_PATH}/solution.xml
			 ssh $MACHINE "cd $REMOTE_PATH ; make all run-hw APPLICATION=$APPLICATION APPLICATION_ARGS="solution.xml" | tee execution.txt ; rm -f solution.xml ; exit"
			 scp $MACHINE:${REMOTE_PATH}/rawData.txt $CURRENT_OUTPUT_DIR/$sched/$sol/rawData.txt
			 scp $MACHINE:${REMOTE_PATH}/defaultProfile.xml $CURRENT_OUTPUT_DIR/$sched/$sol/profile.xml
			 scp $MACHINE:${REMOTE_PATH}/execution.txt $CURRENT_OUTPUT_DIR/$sched/$sol/execution.txt
			 ssh $MACHINE "cd $REMOTE_PATH ; rm -f defaultProfile.xml rawData.txt execution.txt ; exit"
			 java $JAVA_FLAGS TryParseLogKalray -lg $CURRENT_OUTPUT_DIR/$sched/$sol/rawData.txt -gc $CURRENT_OUTPUT_DIR/$sched/$sol/hardware.pdf
			 cp $SCHED_DIR/$sched/$sol/solution.pdf $CURRENT_OUTPUT_DIR/$sched/$sol/solver.pdf
		 done
	done
}


for (( i = 0; i < ${#tests[*]} ; i+=5 ))
do
	if [ "${tests[$i+1]}" == "1" ]; then

		mkdir -p $MAIN_OUTPUT_DIR/${tests[$i]}
		
		# Check if we have to run profiling.
		if [ "${tests[$i+2]}" == "1" ]; then
			profile_application ${tests[$i]} | tee profile_log.txt
			mv profile_log.txt $MAIN_OUTPUT_DIR/${tests[$i]}/profile/
		fi

		# Check if we have to run design flow
		if [ "${tests[$i+3]}" == "1" ]; then
			designFlow ${tests[$i]}
		fi
	
		# Check if we have to execute the app on the hardware.
		if [ "${tests[$i+4]}" == "1" ]; then
			executeOnHardware ${tests[$i]} | tee execution_log.txt
			mv execution_log.txt $MAIN_OUTPUT_DIR/${tests[$i]}/hardware_output
		fi
	fi
done

