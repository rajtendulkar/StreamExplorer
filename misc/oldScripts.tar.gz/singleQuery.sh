#!/bin/bash

INPUT_DIR="outputFiles/"
javac -sourcepath src/ -d bin/ src/*.java -cp dep/Z3Lib/*.jar

FILES=`ls $INPUT_DIR/graph*.xml`

PROCESSORS="16"
GLOBAL_TIMEOUT_IN_SECONDS=600
LOCAL_TIMEOUT_IN_SECONDS=180

EXECUTABLE="exploration.query.oneDimension.SinglePeriodQuery"

###################
# Modulo Scheduling 
###################
for p in $PROCESSORS 
do
	for f in $FILES
	do
		fileName="graph$f"
		
		OUTPUT_DIR="outputFiles/pipeline/modulo_sched/p-$p/"
		java -cp bin $EXECUTABLE -timeout $TIMEOUT_IN_SECONDS -proc $p -leftEdge False -gsym True -psym True -i $fileName -id ${INPUT_DIR} -od ${OUTPUT_DIR}
		timeouts=`cat ${OUTPUT_DIR}/${fileName}/log.txt | grep -i "timeout\|unknown" | wc -l`
		echo "Num Timeouts : $timeouts"

		# We don't continue if we find timeouts
		if [ "$timeouts" -gt 0 ] 
		then
			break  
		fi
	done
done
		
