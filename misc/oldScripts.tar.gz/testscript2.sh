#!/bin/bash

MAIN_OUTPUT_DIR="outputFiles"

PLATFORM_XML="inputFiles/hardware_platform/kalray_mesh.xml"
MACHINE="kalray1-eth0"
REMOTE_PATH="/home/rajtendulkar/workspace/framework_cpp"
PER_QUERY_TIMEOUT_IN_SECONDS=180
TIMEOUT_IN_SECONDS=600

ROOT_DIR="/mnt/extra/eclipse-workspace/Java-WorkSpace/spdf_with_Z3_integrated"
JAR_DIR="$ROOT_DIR/dep/Z3Lib"
BIN_DIR="$ROOT_DIR/bin"

# Compile the Java code.
javac -sourcepath src/ -d bin/ src/*.java -classpath dep/Z3Lib/com.microsoft.z3.jar

# Application-Name      Enable/Disable		Run-Profile 	Run Design Flow 	Execute App on Hardware
tests=( 
"h263"          	 	 "0"				"0"					"1"						"0"
"mp3dec1" 		 		 "1"        		"0"					"1"						"0" 
"mp3dec2"				 "1"				"0"					"1"						"0"
"videoDec1"				 "1"				"0"					"1"						"0"
"videoDec2"				 "1"				"0"					"1"						"0"
"videoDec3"		 	 	 "1"				"0"					"1"						"0"
)

###########################################################################################################

JAVA_FLAGS="-Djava.library.path=$JAR_DIR -classpath $JAR_DIR/com.microsoft.z3.jar:$BIN_DIR:$JAR_DIR"

# Arguments - 
#1 - application name.
function designFlow {
	local APPLICATION=$1
	local CURRENT_OUTPUT_DIR="$MAIN_OUTPUT_DIR/$APPLICATION"
	mkdir -p $CURRENT_OUTPUT_DIR/designFlow/
	local COMMON_FLAGS="-localtimeout $PER_QUERY_TIMEOUT_IN_SECONDS -globaltimeout $TIMEOUT_IN_SECONDS -pg ${PLATFORM_XML} -od ${CURRENT_OUTPUT_DIR}/designFlow/"
	echo "java $JAVA_FLAGS TryDesignFlow -ag ${CURRENT_OUTPUT_DIR}/profile/${APPLICATION}.xml ${COMMON_FLAGS}"
	java $JAVA_FLAGS TryDesignFlow -ag ${CURRENT_OUTPUT_DIR}/profile/${APPLICATION}.xml ${COMMON_FLAGS}
}

for (( i = 0; i < ${#tests[*]} ; i+=5 ))
do
	if [ "${tests[$i+1]}" == "1" ]; then

		mkdir -p $MAIN_OUTPUT_DIR/${tests[$i]}
		
		# Check if we have to run design flow
		if [ "${tests[$i+3]}" == "1" ]; then
			designFlow ${tests[$i]}
		fi
	fi
done

