#!/bin/bash

ROOT_DIR="/mnt/extra/eclipse-workspace/Java-WorkSpace/spdf_with_Z3_integrated"
BIN_DIR="$ROOT_DIR/bin"
JAR_DIR="$ROOT_DIR/dep/Z3Lib"

INPUT_DIR="inputFiles/synthetic_graphs/"
javac -sourcepath src/ -classpath ./dep/Z3Lib/com.microsoft.z3.jar -d bin/ src/*.java 

LOCAL_QUERY_TIMEOUT=180
TIMEOUT_IN_SECONDS=1200
PROCESSORS="2 3 4 5 6 7 8 9 10 11 12 13 14 15 16"
FILE_NUM="1 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 105 110 115 120 125 130 135 140 145 150 200 300 400 500 1000"

###################
# Modulo Scheduling 
###################
for f in $FILE_NUM
do

	for p in $PROCESSORS
	do
		fileName="graph$f"
		
		OUTPUT_DIR="outputFiles/$fileName/"
		java -classpath $BIN_DIR:$JAR_DIR/com.microsoft.z3.jar:$JAR_DIR TryJulienMapping -localtimeout ${LOCAL_QUERY_TIMEOUT} -globaltimeout $TIMEOUT_IN_SECONDS -i $fileName -id ${INPUT_DIR} -od ${OUTPUT_DIR} -proc $p
	done
done
