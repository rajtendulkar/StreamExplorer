#!/bin/bash

INPUT_DIRECTORY=inputFiles/expl_limits
javac -sourcepath src/ -d bin/ src/*.java

FILES=`ls $INPUT_DIRECTORY/graph*.xml`

fileName="videoDec10"
	
OUTPUT_DIRECTORY="outputFiles/videoDecoder/no_sym/$fileName/"
java -cp bin TryGridExploration -i $fileName -od ${OUTPUT_DIRECTORY}
	
OUTPUT_DIRECTORY="outputFiles/videoDecoder/graph_proc_sym/$fileName/"
java -cp bin TryGridExploration -psym True -gsym True -i $fileName -od ${OUTPUT_DIRECTORY}

OUTPUT_DIRECTORY="outputFiles/videoDecoder/graph_sym//$fileName/"
java -cp bin TryGridExploration -gsym True -i $fileName -od ${OUTPUT_DIRECTORY}

OUTPUT_DIRECTORY="outputFiles/videoDecoder/proc_sym/$fileName/"
java -cp bin TryGridExploration -psym True -i $fileName -od ${OUTPUT_DIRECTORY}

