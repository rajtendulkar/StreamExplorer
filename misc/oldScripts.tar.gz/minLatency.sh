#!/bin/bash

INPUT_DIRECTORY=inputFiles/expl_limits
javac -sourcepath src/ -d bin/ src/*.java

FILES=`ls $INPUT_DIRECTORY/graph*.xml`

for f in $FILES
do
	fileName=`echo $f | cut -f3 -d '/' | cut -f1 -d '.'`
	
	OUTPUT_DIRECTORY="outputFiles/expl_limits/no_sym/"
	java -cp bin FindMinLatency -i $fileName -od ${OUTPUT_DIRECTORY}
	
	OUTPUT_DIRECTORY="outputFiles/expl_limits/graph_sym/"
	java -cp bin FindMinLatency -gsym True -i $fileName -od ${OUTPUT_DIRECTORY}
	
	OUTPUT_DIRECTORY="outputFiles/expl_limits/proc_sym/"
	java -cp bin FindMinLatency -psym True -i $fileName -od ${OUTPUT_DIRECTORY}
	
	OUTPUT_DIRECTORY="outputFiles/expl_limits/graph_proc_sym/"
	java -cp bin FindMinLatency -gsym True -psym True -i $fileName -od ${OUTPUT_DIRECTORY}
done
