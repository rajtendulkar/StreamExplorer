#!/bin/bash

PROC_SYM=(False True)
GRAPH_SYM=(False True)
BUFFER_ANALYSIS=(False True)
BUFFER_ANALYSIS_WITH_FUNCTIONS=False
CONFIG_NAME=CONFIG1

SCRIPT_OUTPUT="script_output.txt"
INPUT_DIRECTORY=inputFiles/symmetry_breaking
OUTPUT_DIRECTORY=outputFiles/satsolver
FILES=$INPUT_DIRECTORY/*.xml
javac -sourcepath src/ -d bin/ src/*.java

cfg=1
rm -rf $SCRIPT_OUTPUT
for (( i = 0; i < ${#PROC_SYM[*]} ; i++ ))
do
	for (( j = 0; j < ${#GRAPH_SYM[*]} ; j++ ))
	do
		for (( k = 0; k < ${#BUFFER_ANALYSIS[*]} ; k++ ))
		do
			for f in $FILES
			do
				fileName=`echo $f | cut -f3 -d '/' | cut -f1 -d '.'`
				echo "Exploring for application : $fileName"
				
				FLAGS="-psym ${PROC_SYM[$i]} -gsym ${GRAPH_SYM[$j]} -buffer ${BUFFER_ANALYSIS[$k]} -bufferfunctions $BUFFER_ANALYSIS_WITH_FUNCTIONS"
				
				echo "Config" $cfg " " $fileName "Proc Symmetry : " ${PROC_SYM[$i]} " Graph Symmetry : " ${GRAPH_SYM[$j]} " Buffer Analysis : ${BUFFER_ANALYSIS[$k]}" \
					" Buffer Analysis with Functions : "  ${BUFFER_ANALYSIS_WITH_FUNCTIONS} >> ${SCRIPT_OUTPUT}

				echo "java -cp bin TryGridExploration -i $fileName $FLAGS -id $INPUT_DIRECTORY/ -od $OUTPUT_DIRECTORY/config_$cfg/$fileName/"
				java -cp bin TryGridExploration -i $fileName $FLAGS -id $INPUT_DIRECTORY/ -od $OUTPUT_DIRECTORY/config_$cfg/$fileName/
			done
			cfg=`expr $cfg + 1`
		done
	done
done
